# AFROCODEURS-ORIGINE | AFRO-PAI-012D611626E7 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
"""Ouvre l'explorateur local sur une adresse stable. Ctrl+C pour arrêter."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser

ROOT = Path(__file__).resolve().parent


def main():
    import build_release
    build_release.main()
    handler = partial(SimpleHTTPRequestHandler, directory=str(ROOT / "explorateur/dist"))
    try:
        server = ThreadingHTTPServer(("127.0.0.1", 8765), handler)
    except OSError:
        raise SystemExit("Port 8765 occupé. Si l'explorateur est déjà lancé, ouvrez http://127.0.0.1:8765 ; sinon arrêtez le service qui utilise ce port.")
    print("Explorateur : http://127.0.0.1:8765\nConservez cette adresse et le même navigateur pour retrouver votre progression.")
    webbrowser.open("http://127.0.0.1:8765")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nExplorateur arrêté. La progression reste dans le navigateur.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
