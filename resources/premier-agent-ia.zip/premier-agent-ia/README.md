# Construire son premier agent IA avec Afrocodeurs

Un parcours de la réflexion à l'exécution locale, puis sur VPS. Vous construirez un assistant documentaire capable de chercher dans des fichiers, répondre avec des sources et proposer un compte rendu soumis à validation humaine.

Ce kit Afrocodeurs propose une réalisation technique reproductible, des exercices et un parcours de progression. Il n'est pas affilié aux fournisseurs cités. Le corpus est entièrement fictif : aucune date, inscription ou règle proposée dans les exemples ne constitue une annonce réelle Afrocodeurs.

## Commencer

© 2026 AfroCodeurs — CodeScooper. Toute reproduction ou diffusion, même partielle, des contenus originaux nécessite une autorisation écrite préalable : codescooper@gmail.com, sous réserve des exceptions légales. L'usage personnel nécessaire aux exercices reste autorisé. [Lire les conditions](DROITS-ET-AUTORISATIONS.md).

Pour aller plus loin, transmettre un retour ou rejoindre WhatsApp et Discord : [Rejoindre AfroCodeurs](COMMUNAUTE.md). Les mentions d'origine et le manifeste sont expliqués dans [Traçabilité](TRACABILITE.md).

Vous débutez complètement ? Ouvrez d'abord COMMENCER-ICI.html par double-clic : cette page se lit avant même l'installation de Python. Le [parcours depuis zéro](DEBUTER.md) détaille chaque manipulation, le [lexique et l'aide](AIDE.md) expliquent les erreurs, et les [fiches de pratique accompagnée](PRATIQUE-GUIDEE.md) vous guident pour le vrai modèle et les exercices.

Le kit inclut sa page web locale, avec la charte AfroCodeurs, les polices et les ressources embarquées. Sous Windows, décompresser le ZIP puis double-cliquer sur DEMARRER-WINDOWS.bat ; sinon lancer `python serve.py`. La page s'ouvre à `http://127.0.0.1:8765`, sans compte ni connexion nécessaire pour la lecture. [Mode d'emploi de l'explorateur](EXPLORATEUR.md).

Prérequis : un ordinateur, un terminal et Python 3.11 ou supérieur. Aucune bibliothèque Python à installer. Le parcours comprend trois modes :

| Mode | Internet pendant l'exécution | Coût d'API | Ce qu'il permet de vérifier |
|---|---|---|---|
| Simulation `--demo` | Non | Aucun | Circuit des outils, traces, tests logiciels |
| Ollama local | Non après téléchargement du modèle | Aucun appel facturé par le kit | Comportement réel d'un modèle sur votre matériel |
| API compatible | Oui | Selon le fournisseur | Comportement du modèle distant et intégration |

Dans le dossier contenant ce README, lancer :

```powershell
python -m unittest discover -s tests -v
python agent.py --demo "Quelles sont les conditions d'inscription à l'atelier ?"
```

Résultat attendu : les tests passent, puis une réponse portant la mention SIMULATION s'affiche. Un dossier `runs/<identifiant>/` contient les traces. Ce premier résultat ne prouve aucune capacité d'un LLM.

## Lire et pratiquer dans cet ordre

1. [Tutoriel complet](TUTORIEL.md) : cadrage, préparation, modèle, outils, recherche documentaire, sécurité et évaluation.
2. [Déploiement sur VPS](VPS.md) : exécution privée par SSH, configuration, exploitation et sauvegarde.
3. [Cahier d'exercices](EXERCICES.md) : consignes, corrigés attendus et grille de validation.
4. [Guide des animateurs](ANIMATION.md) : progression pour les ateliers Afrocodeurs.
5. [Sources et limites](SOURCES-ET-LIMITES.md) : documentation officielle et vérifications réellement effectuées.

## Contenu du kit

```text
premier-agent-ia/
  agent.py                 moteur exécutable et CLI
  data/                    deux documents fictifs
  tests/test_agent.py      tests déterministes
  evaluation/cas.json      vingt scénarios à tester avec un vrai modèle
  evaluation/grille.csv    feuille de résultats à remplir
  templates/               cadrage et fiche de mission
  deploy/                  exemple de configuration VPS
  runs/                    créé à l'exécution, exclu de Git
```

Python est retenu pour rendre le moteur lisible. Un SDK ou un framework pourra ensuite remplacer certaines parties ; aucun n'est nécessaire pour comprendre la première boucle. Ce kit est un prototype pédagogique pour un opérateur de confiance. L'ajout d'une interface publique, de comptes utilisateurs ou d'actions métier exige une nouvelle étape d'ingénierie.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-B33563055168. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
