# Animer le parcours du premier agent IA

Public : développeurs débutants, créateurs et membres Afrocodeurs capables de manipuler des fichiers. Prévoir une courte initiation au terminal et à Python pour ceux qui en ont besoin. Les durées sont indicatives ; garder une séance de rattrapage et privilégier les preuves aux cases cochées.

Pour un grand débutant, commencer par COMMENCER-ICI.html puis les six étapes de DEBUTER.md : appareil, fichiers, Python, terminal, simulation et sauvegarde. Utiliser AIDE.md pour le vocabulaire et PRATIQUE-GUIDEE.md pour les manipulations du projet. Prévoir une personne disponible pour les blocages d'installation, de droits administrateur ou de matériel : le support écrit ne garantit pas que tout appareil peut exécuter un modèle local.

La carte adapte les étapes au niveau choisi. Les questions corrigées servent à vérifier la compréhension, pas à certifier une exécution ; les cases restent à cocher sur preuve. Le VPS n'est pas une condition de réussite du parcours principal.

## Progression proposée

| Atelier | Travail principal | Livrable |
|---|---|---|
| 1 — Besoin et première boucle, 2 h | Cadrage, installation Python, simulation, lecture du moteur | Canevas et trace expliquée |
| 2 — Modèle et outils, 2 à 3 h | Ollama ou API, outils structurés, validation d'écriture | Mission avec modèle et rapport approuvé |
| 3 — Documents et évaluation, 2 à 3 h | Recherche, limites du corpus, vingt cas | Grille remplie et erreurs documentées |
| 4 — Robustesse et sécurité, 2 à 3 h | Limites, panne, injection, corrections | Finding et retest |
| 5 — Local et VPS, 2 à 3 h | SSH, configuration privée, traces et sauvegarde | Preuve locale ou VPS explicitement identifiée |
| 6 — Démonstrations, 2 h | Relecture croisée et bilan | Démo de cinq minutes et prochaine évolution |

Prévoir aussi du travail individuel. Ne pas demander à chacun de payer une API : les tests et la simulation fonctionnent sans compte, et un poste Ollama déjà préparé peut servir à une démonstration collective. La simulation ne remplace cependant pas le passage individuel sur un vrai modèle.

## Préparation matérielle

Avant la séance, distribuer le ZIP, vérifier Python et les droits d'installation, télécharger les modèles sur les postes adaptés et tester un vrai appel d'outil. Préparer une solution pour les connexions instables : supports locaux, corpus léger, tests sans Internet. Ne pas mutualiser une clé API dans un groupe WhatsApp ou dans un dépôt.

Le formateur vérifie les modèles et endpoints au moment de l'atelier. Les catalogues et interfaces évoluent. Si un fournisseur n'accepte pas ce format, adapter explicitement `Provider` et retester ; ne pas laisser les débutants déboguer seuls un protocole différent.

## Principes de progression

- Commencer par le workflow métier, la pertinence de l'agent et sa spécification, puis installer et exécuter le projet.
- Ajouter perturbations, preuves, validation d'arguments, limites, état et évaluation.
- Reporter le multi-agents après maîtrise de l'agent unique. Expliquer que plusieurs agents peuvent tourner dans un seul processus : plusieurs machines ne sont pas une obligation.
- Examiner l'impact des attaques avec un corpus hostile fictif et vérifier sa récupération effective.
- Séparer durcissement, déploiement et modèle économique en ateliers distincts pour laisser du temps à la pratique.
- Dans un futur exercice réseau, distinguer présence et exécution : un agent enregistré n'est pas encore un agent exécutant des tâches.

Le kit rassemble les explications, le code et les exercices du parcours Afrocodeurs. Vérifier les droits des ressources externes avant d'ajouter de nouveaux médias à une diffusion publique.

## Après ce premier projet

Proposer ensuite des modules distincts : recherche sémantique, mémoire durable, API privée authentifiée, interface d'approbation, puis multi-agents. Pour ce dernier, comparer un agent unique à deux spécialistes sur le même jeu de cas, mesurer qualité, coût et délai, puis décider si la délégation est utile.

Présenter MCP comme un protocole d'exposition d'outils et de ressources ; il ne remplace ni les permissions ni une validation des arguments. Présenter les échanges inter-agents et les frameworks d'orchestration après les contrats de tâches. Leur installation n'est pas un prérequis pour comprendre la première boucle.

## Avant publication du tutoriel

Faire relire les explications par un débutant et les commandes par une personne disposant d'une machine vierge. Réaliser au moins un passage réel avec Ollama, un fournisseur compatible choisi et un VPS de test. Ajouter ensuite captures ou vidéos correspondant à ces exécutions, avec secrets masqués et résultats datés. Les vérifications déjà effectuées sont listées dans SOURCES-ET-LIMITES.md.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-7AA44B8CB41D. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
