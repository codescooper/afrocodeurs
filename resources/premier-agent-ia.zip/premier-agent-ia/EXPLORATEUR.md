# Explorer le kit et retrouver sa progression

## Ouvrir la page en local

La page et tous ses éléments graphiques sont fournis dans ce dossier. Aucun compte ChatGPT, hébergement externe ou accès Internet n'est nécessaire pour explorer le kit.

Sous Windows, décompresser entièrement le ZIP puis double-cliquer sur DEMARRER-WINDOWS.bat. Sur macOS ou Linux, ouvrir un terminal dans le dossier et lancer `python3 serve.py` ; le fichier demarrer.command fournit la même commande.

On peut aussi lancer directement :

```text
python serve.py
```

Sur Linux ou macOS, utiliser `python3 serve.py`. Le navigateur s'ouvre à `http://127.0.0.1:8765`. Le serveur écoute uniquement sur votre machine et ne lance aucun modèle. Arrêter avec Ctrl+C. Après redémarrage, relancer la même commande et revenir à la même adresse.

## Suivre le parcours

Avant d'installer Python, COMMENCER-ICI.html se lit par double-clic. Une fois le serveur lancé, la carte propose deux parcours : « Je pars de zéro » (16 étapes) et « Je connais le terminal » (10 étapes). Les six étapes d'initiation restent consultables ; le VPS et le dépannage sont facultatifs et ne comptent pas dans le pourcentage du parcours principal.

Chaque fiche contient la leçon complète, deux jalons à cocher après pratique, une question de compréhension avec correction immédiate et une zone de notes. Les ressources permettent aussi de lire ou télécharger le code, les supports et la grille d'évaluation. Le navigateur n'exécute pas Python : les commandes restent à lancer dans votre terminal. Le choix du parcours est conservé avec la progression ; changer de parcours conserve les anciennes cases et notes, mais change le nombre de jalons du pourcentage.

La progression est déclarative, pas une certification automatique. Toutes les étapes restent accessibles, même si les précédentes ne sont pas cochées. Le bouton de reprise ouvre la dernière étape consultée.

## Conserver ses données

Les cases, les notes et la dernière étape sont enregistrées dans le stockage local du navigateur. Elles sont conservées entre les sessions sur la même adresse, le même profil et le même navigateur. Elles ne sont pas synchronisées entre appareils. Si vous aviez commencé sur une autre adresse, utiliser l'export/import pour transférer votre progression.

La navigation privée et l'effacement des données peuvent supprimer cette progression. En cas de stockage indisponible, la page affiche un avertissement. Exporter régulièrement une copie JSON depuis Ma sauvegarde. Pour la reprendre ailleurs, importer le fichier puis confirmer le remplacement de la progression actuelle.

Ne jamais inscrire de clé API ou de données sensibles dans les notes. Sur un poste partagé, exporter puis effacer la progression avant de partir. Ouvrir directement index.html avec une URL file:// n'est pas la méthode recommandée : le comportement du stockage varie selon les navigateurs.

## Reconstruire la distribution

Après modification des supports, exécuter dans cet ordre :

```text
python build_web.py
python build_release.py
```

Le premier programme embarque les leçons et ressources à jour. Le second crée le ZIP, sans secrets ni traces de missions, et le rend téléchargeable depuis la page. Le ZIP embarque les fichiers web ; il ne s'imbrique pas dans lui-même. Le serveur local reconstruit automatiquement la distribution au démarrage.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-DA1F8C17D3A5. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
