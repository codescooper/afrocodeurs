# Droits et autorisations AfroCodeurs

© 2026 AfroCodeurs — CodeScooper. Tous droits réservés sur les contenus originaux du kit « Mon premier agent IA », dans la mesure où ils sont protégés par le droit applicable.

## Reproduction et diffusion

Toute reproduction, même partielle, représentation, adaptation, traduction, republication, redistribution ou exploitation des contenus originaux AfroCodeurs nécessite une demande explicite et une autorisation écrite préalable à obtenir auprès de codescooper@gmail.com, sous réserve des exceptions et droits prévus par la loi applicable.

Une demande envoyée ne vaut pas autorisation. L'accord doit préciser le contenu concerné, l'usage autorisé, les supports, le public, la durée et les conditions éventuelles. Citer AfroCodeurs ou conserver le nom de l'auteur ne remplace pas cette autorisation.

Toute reproduction ou exploitation non autorisée peut exposer son auteur à des poursuites judiciaires et aux conséquences prévues par le droit applicable. Le caractère gratuit d'un partage ou la reproduction d'un extrait ne dispense pas automatiquement de demander une autorisation.

Ne pas supprimer les mentions de droits ni présenter les contenus AfroCodeurs comme les siens. Les identifiants et mentions d'origine font partie de la traçabilité documentaire du kit.

## Usage personnel pour apprendre

Le destinataire peut lire le kit, l'extraire sur son ordinateur, en conserver une sauvegarde personnelle et exécuter ou modifier les exemples pour ses propres exercices privés. Ces opérations techniques et pédagogiques sont autorisées afin de permettre le suivi du parcours.

Cette permission n'autorise pas à republier le kit ou ses adaptations, à le diffuser à un groupe, à l'intégrer dans une formation ou un produit, à le vendre ou à le partager sur un dépôt public. Pour ces usages, même partiels, demander l'autorisation écrite à codescooper@gmail.com. Elle n'enlève aucun droit accordé directement par la loi.

## Ressources de tiers

Les polices Space Grotesk et Geist Mono restent soumises à leurs licences SIL Open Font License, fournies dans explorateur/dist/assets. La présente notice ne retire pas les droits accordés par ces licences. Les logiciels et services cités, ainsi que les pages externes, restent soumis à leurs propres conditions. Le kit ne revendique pas la propriété de ces éléments.

## Demander une autorisation

Écrire à codescooper@gmail.com en précisant :

- votre nom ou votre organisation ;
- les fichiers, passages ou éléments que vous souhaitez reproduire ;
- la finalité, le public et le support de diffusion ;
- l'existence éventuelle d'un usage commercial ;
- les modifications prévues et la durée souhaitée ;
- la référence de version indiquée dans ORIGINE.json, si disponible.

Objet conseillé : « Autorisation de reproduction — Kit premier agent IA AfroCodeurs ».

## Aller plus loin et contribuer

Pour demander un accompagnement, proposer une collaboration ou transmettre un retour d'amélioration, contacter CodeScooper à codescooper@gmail.com. Ces prises de contact ne valent pas autorisation de reproduction. Les liens de la communauté et les consignes pour des retours utiles figurent dans [Rejoindre AfroCodeurs](COMMUNAUTE.md).

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-97EEBB4FC6AB. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
