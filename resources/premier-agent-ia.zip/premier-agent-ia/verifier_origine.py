# AFROCODEURS-ORIGINE | AFRO-PAI-0DED734AF532 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
"""Compare les fichiers locaux au manifeste, sans connexion Internet."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
KIT_ID = 'AFROCODEURS-PREMIER-AGENT-2026'


def verify(root):
    try:
        data = json.loads((root / 'ORIGINE.json').read_text(encoding='utf-8'))
        if data.get('kit_id') != KIT_ID or data.get('format') != 1 or not isinstance(data.get('files'), list) or not data['files']:
            return ['Manifeste non reconnu ou vide']
        issues, seen = [], set()
        for entry in data['files']:
            name = entry['path']
            if not isinstance(name, str) or name in seen:
                raise ValueError('Chemin invalide ou répété')
            seen.add(name)
            target = (root / name).resolve()
            if not target.is_relative_to(root.resolve()):
                raise ValueError('Chemin hors du dossier du kit')
            if not target.is_file():
                issues.append('Absent : ' + name)
            elif hashlib.sha256(target.read_bytes()).hexdigest() != entry['sha256']:
                issues.append('Modifié : ' + name)
        return issues
    except (OSError, ValueError, TypeError, KeyError):
        return ['Manifeste absent, illisible ou invalide']


def main():
    issues = verify(ROOT)
    if issues:
        print('\n'.join(issues))
        print('Un exercice modifié peut expliquer cet écart. Contact : codescooper@gmail.com')
        return 1
    print('Fichiers conformes au manifeste présent. Origine déclarée : AfroCodeurs — CodeScooper.')
    print('Ce contrôle ne certifie pas la propriété ni un horodatage. Voir TRACABILITE.md.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
