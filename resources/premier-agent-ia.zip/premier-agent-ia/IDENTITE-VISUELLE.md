# Identité visuelle AfroCodeurs du kit local

La page reprend les tokens graphiques et les polices effectivement utilisés par le site AfroCodeurs, vérifiés le 25 novembre 2026. Elle conserve la carte du parcours déjà choisie.

## Palette

| Usage | Couleur du site |
|---|---|
| Fond sombre | #0D0C0A |
| Texte principal | #FAFAF8 |
| Or de marque et actions principales | #F5B800 |
| Texte sur or | #111111 |
| Vert de validation | #22C55E |
| Surface | #141310 |
| Surface secondaire | #1F1E1A |
| Texte secondaire | #A3A29C |
| Bordures | #2A2924 |

## Typographie et signature

Space Grotesk pour l'interface et Geist Mono pour le code et les repères techniques. Les fichiers WOFF2 sont intégrés dans le dossier assets, avec les licences SIL Open Font License. Aucun chargement de police distante n'est requis.

Le bloc de marque reprend la signature typographique du site : signe `<A/>`, AFRO en or et CODEURS en clair. Il remplace le signe provisoire du précédent prototype. Ce n'est pas un nouveau logo dessiné pour le kit.

La signature « Le code transforme demain. » et la mention « Communauté tech africaine » proviennent de la page AfroCodeurs consultée. Aucune scène, inscription ou fonctionnalité du site public n'est importée dans le kit.

## Références vérifiées

- https://www.afrocodeurs.org : HTML et CSS du site consultés directement le 25 novembre 2026 ; tokens du thème sombre, déclarations font-face et structure de marque.
- Sources locales du projet AfroCodeurs : app/globals.css, app/layout.tsx et app/construction/construction.module.css ; correspondance des tokens et des familles de polices.
- https://github.com/google/fonts/tree/main/ofl/spacegrotesk et https://github.com/google/fonts/tree/main/ofl/geistmono : licences de redistribution des polices.

La page de construction possède également des effets décoratifs propres à son écran d'attente. Ils ne sont pas nécessaires à la lecture du tutoriel ; l'identité de l'interface repose sur les tokens, les polices et la signature vérifiés.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-BB99D802F0B4. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
