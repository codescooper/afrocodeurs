#!/bin/sh
# AFROCODEURS-ORIGINE | AFRO-PAI-C81B473A9932 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
cd "$(dirname "$0")" || exit 1
exec python3 serve.py
