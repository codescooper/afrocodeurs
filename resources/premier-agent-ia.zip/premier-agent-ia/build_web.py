# AFROCODEURS-ORIGINE | AFRO-PAI-0CFEAA3DDCA9 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
"""Embarque les contenus du kit dans la page sans dépendance réseau."""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
META = [
    ("cadrer", "Cadrer votre agent", "Partir d'un besoin concret et fixer les limites.", "RÉFLÉCHIR", "35 min", ["Mon besoin et mon utilisateur sont décrits.", "Mes outils et interdictions sont définis."]),
    ("installer", "Préparer le terrain", "Installer Python et faire tourner la simulation.", "PRÉPARER", "30 min", ["Les tests passent sur mon ordinateur.", "J'ai exécuté et expliqué la simulation."]),
    ("modele", "Brancher un vrai modèle", "Choisir Ollama ou une API et observer un appel réel.", "CONNECTER", "60 min", ["Mon modèle et son emplacement sont identifiés.", "Une recherche réelle apparaît dans la trace."]),
    ("outils", "Donner des outils", "Comprendre la boucle et contrôler les écritures.", "CONSTRUIRE", "60 min", ["Je peux expliquer chaque tour de la boucle.", "J'ai testé le refus puis l'accord d'écriture."]),
    ("documents", "Ancrer les réponses", "Chercher dans les documents et vérifier les sources.", "ENRICHIR", "50 min", ["Chaque fait de ma réponse a une source.", "J'ai testé une question sans réponse dans le corpus."]),
    ("memoire", "Garder une trace", "Distinguer mémoire, état sauvegardé et vraie reprise.", "COMPRENDRE", "40 min", ["J'ai inspecté state.json et events.jsonl.", "Je comprends les limites de reprise après coupure."]),
    ("robustesse", "Tester les limites", "Observer les pannes, les boucles et les coûts.", "ÉPROUVER", "60 min", ["J'ai provoqué un arrêt contrôlé.", "J'ai relevé les appels et la consommation disponible."]),
    ("securite", "Protéger les actions", "Évaluer une manipulation et ses conséquences réelles.", "PROTÉGER", "60 min", ["Mon test hostile a réellement été récupéré.", "J'ai documenté le résultat et un retest."]),
    ("vps", "Passer sur un VPS", "Déployer un outil privé, accessible par SSH.", "DÉPLOYER", "90 min", ["Les tests et une mission fonctionnent sur le VPS.", "J'ai restauré une sauvegarde dans un autre dossier."]),
    ("demo", "Montrer ce qui fonctionne", "Préparer une démonstration avec des preuves.", "DÉMONTRER", "40 min", ["Ma démo distingue simulation et modèle réel.", "Je peux montrer un succès et un échec contrôlé."]),
    ("depannage", "Savoir débloquer", "Identifier un symptôme et vérifier sa cause.", "DIAGNOSTIQUER", "25 min", ["Je sais retrouver le statut et les traces d'une erreur.", "Je peux expliquer une correction vérifiée."]),
    ("evaluation", "Valider votre premier agent", "Faire les exercices et documenter les vingt scénarios.", "VALIDER", "120 min", ["Mes vingt scénarios sont documentés.", "J'ai retesté les cas critiques et identifié les limites."]),
]

STARTERS = [
    ("depart", "Choisir votre point de départ", "Comprendre l'objectif et choisir selon votre appareil.", ["J'ai identifié mon appareil et mon système.", "Je distingue la simulation d'un vrai modèle."]),
    ("fichiers", "Retrouver vos fichiers", "Extraire le ZIP et reconnaître le dossier du projet.", ["J'ai extrait le ZIP dans un dossier personnel.", "Je vois agent.py et COMMENCER-ICI.html."]),
    ("python", "Installer Python", "Obtenir une version utilisable avant de continuer.", ["Une commande affiche Python 3.11 ou supérieur.", "Je sais distinguer le terminal de l'invite >>>."]),
    ("terminal", "Ouvrir le bon terminal", "Se placer dans le dossier du kit et lancer le diagnostic.", ["La liste du dossier courant contient agent.py.", "Le diagnostic local affiche ses vérifications OK."]),
    ("simulation", "Votre première réussite", "Exécuter sans modèle et retrouver les preuves.", ["J'ai obtenu la mention SIMULATION et le statut attendu.", "J'ai retrouvé les compteurs et des tests terminés par OK."]),
    ("carte", "Retrouver votre progression", "Ouvrir la page et sauvegarder votre travail.", ["Une case et une note restent après actualisation.", "J'ai exporté ma progression dans un fichier JSON."]),
]

QUIZZES = {
    "depart": ("La simulation prouve-t-elle la qualité d'un vrai modèle ?", ["Oui, elle utilise déjà un LLM.", "Non, ses décisions sont prédéfinies."], 1, "La simulation teste le circuit logiciel. Il faut un vrai modèle et une évaluation pour juger les réponses."),
    "fichiers": ("Où faut-il lancer le projet ?", ["Dans le dossier extrait contenant agent.py.", "À l'intérieur du ZIP."], 0, "Il faut extraire les fichiers pour que le programme puisse lire et écrire dans son dossier."),
    "python": ("Vous voyez >>>. Où êtes-vous ?", ["Dans le terminal prêt aux commandes python.", "Dans l'interpréteur Python ; exit() permet d'en sortir."], 1, "Les commandes du guide se saisissent dans le terminal, pas dans l'interpréteur affichant >>>."),
    "terminal": ("agent.py est introuvable. Que vérifier en premier ?", ["Le dossier courant du terminal.", "La puissance du modèle IA."], 0, "Le terminal doit être placé dans le dossier qui contient le fichier à exécuter."),
    "simulation": ("completed_unverified signifie…", ["La réponse est forcément correcte.", "Une réponse finale a été produite, elle reste à vérifier."], 1, "Le programme constate la fin ; un relecteur doit encore vérifier les faits et les sources."),
    "carte": ("L'export de progression contient-il les rapports de runs ?", ["Non, seulement les notes, cases et préférences du guide.", "Oui, tous les fichiers de l'agent."], 0, "Les preuves dans runs doivent être sauvegardées séparément."),
    "cadrer": ("Quel est un critère vérifiable ?", ["L'agent est intelligent.", "La réponse cite le passage qui donne la version Python requise."], 1, "Un critère précis permet de comparer le résultat à une preuve."),
    "installer": ("À quoi sert .venv ?", ["À isoler l'environnement Python du projet.", "À héberger le modèle IA."], 0, "Un environnement virtuel Python n'est ni un modèle ni un serveur."),
    "modele": ("Quelle adresse désigne le guide local ?", ["127.0.0.1:11434/v1", "127.0.0.1:8765"], 1, "8765 sert le guide ; 11434 est le port Ollama utilisé dans l'exemple."),
    "outils": ("Qui autorise réellement l'écriture du rapport ?", ["Le modèle tout seul.", "Le programme contrôle la proposition et demande l'accord humain."], 1, "Le modèle propose un outil ; le code et la validation humaine contrôlent son exécution."),
    "documents": ("Un numéro de téléphone est absent du corpus. Que faire ?", ["Donner un numéro plausible.", "Signaler l'information absente."], 1, "Une réponse plausible sans source reste une invention."),
    "memoire": ("Reprendre mon parcours relance-t-il une mission interrompue ?", ["Non, cela reprend la lecture du guide.", "Oui, le travail de l'agent redémarre automatiquement."], 0, "La progression pédagogique et l'état d'exécution sont deux choses distinctes."),
    "robustesse": ("step_limit prouve-t-il une réussite ?", ["Non, il indique l'atteinte d'une limite de la boucle.", "Oui, l'agent a trouvé sa réponse."], 0, "Un arrêt contrôlé peut empêcher une boucle sans produire de réponse finale correcte."),
    "securite": ("Le texte hostile n'a jamais été récupéré. L'injection est-elle testée ?", ["Oui, aucune attaque n'a réussi.", "Non, le modèle n'a pas été exposé au passage."], 1, "Vérifier la récupération est nécessaire pour interpréter ce test."),
    "vps": ("Faut-il un VPS pour valider son premier agent ?", ["Oui, obligatoirement.", "Non, une exécution locale avec preuves suffit."], 1, "Le VPS est un prolongement, pas une condition d'apprentissage initiale."),
    "demo": ("Quelle preuve montrer en démonstration ?", ["Le modèle dit mission accomplie.", "Une source, une trace et le résultat réellement produit."], 1, "Un message de réussite ne démontre pas à lui seul une action."),
    "depannage": ("Pour diagnostiquer, il vaut mieux…", ["Changer une chose et retester la même commande.", "Modifier plusieurs fichiers au hasard."], 0, "Une seule modification à la fois permet d'identifier sa cause et son effet."),
    "evaluation": ("Un test réussi sur une question suffit-il ?", ["Non, il faut plusieurs cas et retester les cas critiques.", "Oui, on peut généraliser immédiatement."], 0, "Un résultat isolé ne démontre pas la fiabilité générale."),
}


def main():
    tutorial = (ROOT / "TUTORIEL.md").read_text(encoding="utf-8")
    parts = re.split(r"(?m)^## \d+ ", tutorial)[1:]
    contents = ["## " + text for text in parts[:8]]
    contents += [(ROOT / "VPS.md").read_text(encoding="utf-8"), "## " + parts[8],
                 "## " + parts[9], (ROOT / "EXERCICES.md").read_text(encoding="utf-8")]
    lessons = [dict(id=id_,title=title,description=desc,phase=phase,duration=duration,
                    checks=checks,content=content)
               for (id_,title,desc,phase,duration,checks),content in zip(META,contents)]
    intro = re.split(r"(?m)^## \d+ ", (ROOT / "DEBUTER.md").read_text(encoding="utf-8"))[1:]
    if len(intro) != len(STARTERS) or len(parts) != 10:
        raise ValueError("Les sections du guide ont changé : vérifier leur association aux étapes web")
    starters = [dict(id=id_,title=title,description=desc,phase="PREMIERS PAS",duration="À votre rythme",
                     checks=checks,content="## " + content,beginner=True)
                for (id_,title,desc,checks),content in zip(STARTERS,intro)]
    practice = (ROOT / "PRATIQUE-GUIDEE.md").read_text(encoding="utf-8")
    guided = dict(re.findall(r"(?ms)^## ([a-z]+)\n(.*?)(?=^## [a-z]+\n|\Z)", practice))
    for lesson in lessons:
        if lesson["id"] in guided:
            lesson["content"] += "\n\n## Mise en pratique accompagnée\n" + guided[lesson["id"]]
        lesson["optional"] = lesson["id"] in {"vps", "depannage"}
    lessons = starters + lessons
    for lesson in lessons:
        question,options,correct,explanation = QUIZZES[lesson["id"]]
        lesson["quiz"] = dict(question=question,options=options,correct=correct,explanation=explanation)
        from marquer_origine import file_id
        lesson['originId'] = file_id('lecon:'+lesson['id'])
    resources = []
    for name in ["README.md","COMMUNAUTE.md","DROITS-ET-AUTORISATIONS.md","TRACABILITE.md","DEBUTER.md","AIDE.md","PRATIQUE-GUIDEE.md","TUTORIEL.md","VPS.md","EXERCICES.md","ANIMATION.md",
                 "SOURCES-ET-LIMITES.md","VALIDATION.md","IDENTITE-VISUELLE.md","EXPLORATEUR.md","agent.py","tests/test_agent.py",
                 "data/ateliers.md","data/charte.md","templates/CADRAGE.md",
                 "templates/FICHE-MISSION.md","evaluation/cas.json","evaluation/grille.csv",
                 "deploy/provider.env.example"]:
        resources.append(dict(id=name,title=name,originId=file_id(name),content=(ROOT/name).read_text(encoding="utf-8")))
    output = ROOT / "explorateur/dist/kit-data.js"
    output.write_text("window.AFRO_KIT = " + json.dumps({"lessons":lessons,"resources":resources},ensure_ascii=False) + ";\n",encoding="utf-8")
    print(f"{len(lessons)} étapes et {len(resources)} ressources embarquées.")


if __name__ == "__main__":
    main()
