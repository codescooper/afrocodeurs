# Validation du kit

Contrôles réalisés le 25 novembre 2026 sous Windows avec Python 3.12.10.

## Tests logiciels

Commande : `python -m unittest discover -s tests -v`

Résultat : **16 tests réussis**. Couverture : recherche et absence de correspondance, noms d'outils inconnus, arguments supplémentaires et types invalides, refus d'écriture, approbation et refus d'écrasement, état et journal, limites d'appels, JSON invalide, erreur fournisseur, réponse finale vide, délai dépassé avant outil, refus d'HTTP distant et adaptateur HTTP local sur deux tours.

Le test HTTP utilise une clé factice et un serveur simulé sur loopback. Il vérifie le chemin de requête, le retour du résultat d'outil au fournisseur, la collecte des tokens et l'absence de la clé dans l'état. Aucun service payant n'est appelé.

## Parcours de simulation

Commande : `python agent.py --demo "Quelles sont les conditions d'inscription à l'atelier ?"`

Résultat : réponse explicitement simulée, état `completed_unverified`, deux appels simulés, un outil de recherche et traces créées dans `runs/`. Les fichiers JSON sont en UTF-8. Le rendu des accents dans une capture de terminal dépend de l'encodage du terminal.

## Distribution

Le script `build_release.py` vérifie les liens Markdown locaux, la présence des fichiers distribués, l'unicité des vingt scénarios et l'intégrité ZIP. Il utilise une liste explicite de fichiers : les missions, `.venv`, caches et secrets sont exclus.

Le ZIP est également extrait dans un dossier temporaire pour rejouer les tests et la simulation depuis les seuls fichiers distribués. Les résultats de ce contrôle sont consignés dans la livraison du chat.

## Vérifications restantes

Ollama réel, API réelle, qualité des réponses sur les vingt scénarios, VPS Ubuntu et parcours débutant sur machine vierge n'ont pas été exécutés. Le code et les commandes sont prêts pour ces essais ; leurs résultats ne sont pas présumés. Voir SOURCES-ET-LIMITES.md.

## Explorateur web

Douze étapes, vingt-quatre jalons et seize ressources embarquées. Dix contrôles Node du stockage passent ; syntaxe des scripts vérifiée. En navigateur : cases et notes restaurées après rechargement, export JSON et réimport avec confirmation, recherche et navigation testées. Lien d'évitement corrigé et retesté. Contrôle DOM sans débordement global aux largeurs 320, 390, 768 et 1440.

Aucun redémarrage physique de la machine, audit lecteur d'écran complet ou audit axe n'a été effectué. La persistance intersessions repose sur localStorage ; les limites et la sauvegarde exportable sont expliquées. Aucune dépendance QA n'a été installée.

## Distribution locale et marque AfroCodeurs

La distribution inclut son explorateur, les lanceurs Windows et shell, quatre fichiers WOFF2 (deux familles, sous-ensembles latin et latin étendu) et leurs licences. La palette a été comparée aux CSS du site AfroCodeurs. Le navigateur confirme le fond rgb(13,12,10), la famille Space Grotesk déclarée et la signature <A/>AFROCODEURS. Pas de débordement global observé à 390 px. La configuration de publication est exclue du kit.

## Parcours depuis zéro

Mise à jour du 25 novembre 2026 : 18 fiches disponibles, dont 16 dans le parcours débutant et 10 dans le parcours connaissant le terminal ; VPS et dépannage facultatifs. 18 questions de compréhension avec correction immédiate. COMMENCER-ICI.html se lit avant l'installation de Python ; DEBUTER.md, AIDE.md et PRATIQUE-GUIDEE.md détaillent les manipulations.

Vérifications : 16 tests Python et 16 groupes de contrôles JavaScript réussis ; diagnostic local exécuté ; arrêt step_limit reproduit avec la commande de l'exercice. Dans le navigateur, changement de parcours puis rechargement conserve le choix ; les compteurs passent de 16 à 10 étapes ; réponses fausse puis correcte affichent leurs explications ; leçon mobile à 390 px sans débordement global. La validation des anciennes sauvegardes sans champ path conserve cases et notes.

Les étapes n'ont pas encore été suivies par un débutant externe sur une machine vierge. Les installations Windows/macOS/Linux, l'API réelle, Ollama réel et le VPS conservent les limites de validation déjà signalées. Aucun résultat utilisateur ou succès sur tout matériel n'est supposé.


## Droits communauté et traçabilité

25 novembre 2026 : notice de reproduction, contact codescooper@gmail.com et liens communautaires intégrés. Liens WhatsApp et Discord retrouvés dans le HTML du site officiel ; invitation Discord confirmée par son API publique (HTTP 200, serveur AfroCodeurs). Aucun groupe rejoint et aucun message envoyé.

Vérifications : 23 tests Python réussis, dont 7 pour les fichiers intacts, modifiés, absents, le manifeste invalide, les chemins hors dossier et les marques répétées. 16 groupes de contrôles JavaScript réussis. Page communauté et notice observées dans le navigateur ; notice mobile à 390 px sans débordement global. Le vérificateur ne contacte aucun serveur. Les empreintes et mentions d'origine ne sont pas une preuve juridique autonome.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-37959855B8C9. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
