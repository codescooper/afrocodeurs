# AFROCODEURS-ORIGINE | AFRO-PAI-E322F4A49287 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import marquer_origine
import verifier_origine


class ProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / 'support.md').write_text('# Exemple\n\nContenu pédagogique.\n', encoding='utf-8')

    def manifest(self, path='support.md', digest=None):
        data = {'format': 1, 'kit_id': verifier_origine.KIT_ID,
                'files': [{'path': path, 'sha256': digest or hashlib.sha256((self.root / 'support.md').read_bytes()).hexdigest()}]}
        (self.root / 'ORIGINE.json').write_text(json.dumps(data), encoding='utf-8')

    def test_intact_file(self):
        self.manifest()
        self.assertEqual(verifier_origine.verify(self.root), [])

    def test_changed_file(self):
        self.manifest()
        (self.root / 'support.md').write_text('Modifié', encoding='utf-8')
        self.assertEqual(verifier_origine.verify(self.root), ['Modifié : support.md'])

    def test_missing_file(self):
        self.manifest('absent.md')
        self.assertEqual(verifier_origine.verify(self.root), ['Absent : absent.md'])

    def test_path_escape_rejected(self):
        self.manifest('../ailleurs.txt')
        self.assertEqual(verifier_origine.verify(self.root), ['Manifeste absent, illisible ou invalide'])

    def test_bad_manifest(self):
        (self.root / 'ORIGINE.json').write_text('{bad', encoding='utf-8')
        self.assertTrue(verifier_origine.verify(self.root))

    def test_marking_is_idempotent(self):
        (self.root / 'style.css').write_text('@charset "UTF-8";\nbody{color:red}', encoding='utf-8')
        (self.root / 'script.py').write_text('"""Exemple."""\nprint("bonjour")\n', encoding='utf-8')
        with patch.object(marquer_origine, 'ROOT', self.root):
            files = ['support.md', 'style.css', 'script.py']
            marquer_origine.main(files)
            before = {name: (self.root / name).read_bytes() for name in files}
            marquer_origine.main(files)
            self.assertEqual(before, {name: (self.root / name).read_bytes() for name in files})

    def test_new_text_after_mark_is_not_lost(self):
        with patch.object(marquer_origine, 'ROOT', self.root):
            marquer_origine.main(['support.md'])
            with (self.root / 'support.md').open('a', encoding='utf-8') as output:
                output.write('\nNouvelle section à préserver.\n')
            marquer_origine.main(['support.md'])
        text = (self.root / 'support.md').read_text(encoding='utf-8')
        self.assertIn('Nouvelle section à préserver.', text)
        self.assertEqual(text.count('Référence AFRO-PAI-'), 1)


if __name__ == '__main__':
    unittest.main()
