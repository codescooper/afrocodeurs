# AFROCODEURS-ORIGINE | AFRO-PAI-359C72157A99 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
import json
from pathlib import Path
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from unittest.mock import patch
import agent


def tool(name, args):
    return {"role": "assistant", "content": None, "tool_calls": [{"id": "call-1",
        "type": "function", "function": {"name": name, "arguments": args}}]}


class Scripted:
    model = "test-scripted"
    def __init__(self, messages):
        self.messages = iter(messages)
    def complete(self, messages, timeout):
        item = next(self.messages)
        if isinstance(item, Exception):
            raise item
        return item, {}


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.docs = self.root / "data"
        self.docs.mkdir()
        (self.docs / "atelier.md").write_text("Inscription gratuite à l'atelier Python.", encoding="utf-8")
        self.output = self.root / "output"
        self.output.mkdir()

    def execute(self, name, args, approve=lambda text: False):
        return agent.execute_tool(name, args, self.docs, self.output, approve)

    def run_agent(self, provider, **kwargs):
        return agent.run("Comment s'inscrire ?", provider, docs=self.docs,
                         runs=self.root / "runs", approve=lambda text: False, **kwargs)

    def test_search_sources(self):
        result = self.execute("search_docs", {"query": "inscription"})
        self.assertEqual(result["matches"][0]["source"], "atelier.md")

    def test_unknown_fact_returns_empty(self):
        self.assertEqual(self.execute("search_docs", {"query": "astronomie"})["matches"], [])

    def test_unknown_tool_blocked(self):
        self.assertEqual(self.execute("execute_shell", {"cmd": "whoami"})["error"], "unknown_tool")

    def test_extra_path_blocked(self):
        result = self.execute("save_report", {"content": "x", "path": "../../bad"})
        self.assertEqual(result["error"], "invalid_arguments")

    def test_invalid_types(self):
        for value in [None, 7, {}, [], "", "x" * 501]:
            self.assertEqual(self.execute("search_docs", {"query": value})["error"], "invalid_arguments")

    def test_write_denied(self):
        self.assertFalse(self.execute("save_report", {"content": "brouillon"})["saved"])
        self.assertFalse((self.output / "rapport.md").exists())

    def test_write_approved_and_not_overwritten(self):
        self.assertTrue(self.execute("save_report", {"content": "brouillon"}, lambda _: True)["saved"])
        self.assertFalse(self.execute("save_report", {"content": "autre"}, lambda _: True)["saved"])
        self.assertEqual((self.output / "rapport.md").read_text(encoding="utf-8"), "brouillon")

    def test_demo_and_checkpoint(self):
        state, folder = self.run_agent(agent.DemoProvider())
        self.assertEqual(state["status"], "completed_unverified")
        self.assertEqual(state["tool_calls"], 1)
        self.assertEqual(json.loads((folder / "state.json").read_text(encoding="utf-8"))["status"], state["status"])
        self.assertIn('"event": "end"', (folder / "events.jsonl").read_text(encoding="utf-8"))

    def test_loop_limit(self):
        state, _ = self.run_agent(Scripted([tool("search_docs", '{"query":"atelier"}')]*4), max_steps=2)
        self.assertEqual(state["status"], "step_limit")
        self.assertEqual(state["model_calls"], 2)

    def test_tool_limit(self):
        message = tool("search_docs", '{"query":"atelier"}')
        message["tool_calls"] *= 3
        state, _ = self.run_agent(Scripted([message]), max_tools=1)
        self.assertEqual(state["status"], "tool_limit")
        self.assertEqual(state["tool_calls"], 1)

    def test_bad_json_returned_to_model(self):
        state, _ = self.run_agent(Scripted([tool("search_docs", '{bad'), {"role":"assistant", "content":"Erreur signalée"}]))
        self.assertIn("invalid_arguments", state["messages"][-2]["content"])

    def test_provider_failure(self):
        state, _ = self.run_agent(Scripted([TimeoutError("secret-in-error")]))
        self.assertEqual(state["status"], "failed")
        self.assertNotIn("secret-in-error", json.dumps(state))

    def test_empty_answer_fails(self):
        state, _ = self.run_agent(Scripted([{"role":"assistant", "content":""}]))
        self.assertEqual(state["status"], "failed")

    def test_late_response_cannot_write(self):
        with patch("agent.time.monotonic", side_effect=[0, 0, 2, 2]):
            state, _ = self.run_agent(Scripted([tool("save_report", '{"content":"late"}')]), deadline=1)
        self.assertEqual(state["status"], "time_limit")
        self.assertEqual(state["tool_calls"], 0)

    def test_remote_plain_http_rejected(self):
        with patch.dict("os.environ", {"AGENT_BASE_URL":"http://example.com/v1"}):
            with self.assertRaises(ValueError):
                agent.Provider()

    def test_http_adapter_two_turns(self):
        requests_seen = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass
            def do_POST(self):
                payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                requests_seen.append((self.path, payload, self.headers.get("Authorization")))
                message = (tool("search_docs", '{"query":"inscription"}') if len(requests_seen) == 1
                           else {"role":"assistant", "content":"Inscription gratuite [atelier.md]."})
                encoded = json.dumps({"choices":[{"message":message}],
                                      "usage":{"total_tokens":12}}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(encoded)))
                self.end_headers()
                self.wfile.write(encoded)
        server = HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with patch.dict("os.environ", {"AGENT_BASE_URL":f"http://127.0.0.1:{server.server_port}/v1",
                                           "AGENT_MODEL":"test-model", "AGENT_API_KEY":"fake-test-key"}):
                state, folder = self.run_agent(agent.Provider())
            self.assertEqual(state["status"], "completed_unverified")
            self.assertEqual(len(requests_seen), 2)
            self.assertEqual(requests_seen[0][0], "/v1/chat/completions")
            self.assertEqual(requests_seen[0][2], "Bearer fake-test-key")
            self.assertEqual(requests_seen[1][1]["messages"][-1]["role"], "tool")
            self.assertEqual(state["usage"], [{"total_tokens":12}]*2)
            self.assertNotIn("fake-test-key", (folder / "state.json").read_text(encoding="utf-8"))
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == "__main__":
    unittest.main()
