# Je pars de zéro

Ce parcours ne demande pas de savoir programmer. Vous allez apprendre à manipuler le dossier du kit, ouvrir un terminal et lancer un premier programme. Ne cherchez pas à tout mémoriser : gardez ce guide ouvert et effectuez une action à la fois. Vous pouvez faire une pause après chaque résultat vérifié.

Il faut un ordinateur Windows 10/11, macOS ou Linux sur lequel vous avez le droit d'installer Python. Sur téléphone ou tablette, vous pouvez lire et prendre des notes ; les exercices de ce kit nécessitent un ordinateur ou un accès à un ordinateur distant préparé. Si votre ordinateur est administré par une école ou une entreprise, demander l'installation autorisée à son responsable. Ne pas contourner les restrictions.

## 1 Trouver son point de départ

### Ce que vous allez obtenir

Un programme auquel vous donnez une mission. Il consulte deux documents d'exemple, propose une réponse et peut préparer un rapport. Les documents parlent d'un atelier fictif : il n'y a aucune inscription réelle à effectuer.

La première réussite sera une simulation gratuite. Vous brancherez ensuite un vrai modèle si votre matériel ou une API vous le permet. La simulation seule n'est pas encore un agent IA utilisant un modèle.

### Choisir sa route

- Vous découvrez le terminal : choisir « Je pars de zéro » dans la carte et commencer ici.
- Vous connaissez déjà les commandes et les fichiers : choisir « Je connais le terminal ». Les leçons d'initiation restent disponibles.
- Vous avez peu de mémoire ou une connexion limitée : terminer d'abord la simulation, sans installer Ollama.
- Vous n'avez pas d'ordinateur : lire les étapes et préparer le cadrage ; pour exécuter, organiser un créneau sur un ordinateur de formation. Un téléphone seul n'est pas pris en charge par ces instructions.

### À faire maintenant

Écrivez dans vos notes : « Je travaille sur Windows / macOS / Linux. Mon objectif est de comprendre et lancer un premier agent. » Choisissez seulement votre système, pas les trois.

### Vérifier avant de continuer

Vous savez quel appareil vous utiliserez et vous comprenez qu'aucun paiement n'est nécessaire pour commencer.

## 2 Décompresser et reconnaître les fichiers

### Où faire cette action

Dans l'Explorateur de fichiers sous Windows, le Finder sous macOS ou le gestionnaire de fichiers sous Linux. Un ZIP est un paquet compressé : il faut en sortir les fichiers avant de les lancer.

### Une action à la fois

1. Téléchargez premier-agent-ia.zip et retrouvez-le dans Téléchargements.
2. Sous Windows, clic droit sur le ZIP puis « Extraire tout ». Sous macOS, double-cliquez sur le ZIP. Sous Linux, utilisez « Extraire » dans le gestionnaire d'archives.
3. Choisissez un dossier personnel où vous pouvez écrire. Sous Windows, par exemple Documents, puis un dossier Formation Afrocodeurs.
4. Ouvrez le dossier extrait premier-agent-ia. S'il contient encore un dossier du même nom, ouvrez le second : vous devez voir agent.py et README.md ensemble.
5. Sous Windows, dans Afficher, activez l'affichage des extensions de noms de fichiers. Les noms de menus varient légèrement suivant la version.

### Ce que vous devez voir

```text
premier-agent-ia
  COMMENCER-ICI.html
  DEMARRER-WINDOWS.bat
  agent.py
  diagnostic.py
  README.md
  data
  tests
```

Un fichier .py contient du Python. Un .md contient du texte mis en forme, lisible dans un éditeur. Un dossier contient d'autres fichiers. Ne renommez pas agent.py et ne lancez pas les fichiers depuis l'intérieur du ZIP.

### Si cela bloque

Si vous voyez « Extraire tout » en haut de la fenêtre, vous êtes peut-être encore dans l'archive. Revenez au dossier que vous avez choisi pour l'extraction. Si l'écriture est refusée, choisissez votre dossier Documents plutôt qu'un dossier système. Si un outil de sécurité bloque un fichier, ne désactivez pas cette protection : gardez le message et demandez de l'aide.

### Petite réussite

Ouvrez COMMENCER-ICI.html par double-clic. Cette page fonctionne sans Python et explique le démarrage. Puis revenez à ce guide.

## 3 Installer et reconnaître Python

### Comprendre avant d'agir

Python est le programme qui lit nos fichiers .py. Le terminal est une fenêtre dans laquelle vous lui donnez des commandes. Installer Python ne télécharge pas un modèle IA et ne crée pas de compte payant.

### Windows

1. Ouvrez le site officiel [Téléchargements Python](https://www.python.org/downloads/windows/).
2. Utilisez le gestionnaire d'installation recommandé par le site et suivez ses instructions. Si vous utilisez un installateur classique proposant « Add Python to PATH », cette option rend la commande accessible depuis le terminal.
3. Terminez l'installation, puis fermez et rouvrez le terminal s'il était déjà ouvert. Les écrans évoluent : la vérification par commande ci-dessous compte davantage que l'emplacement exact d'un bouton.
4. Ouvrez le menu Démarrer, saisissez PowerShell et ouvrez-le normalement, sans mode administrateur.
5. Copiez cette seule ligne et appuyez sur Entrée :

```powershell
python --version
```

Si cette commande ne fonctionne pas, essayez :

```powershell
py --version
```

Vous devez voir Python 3.11 ou une version supérieure, par exemple Python 3.12.10. Ne copiez pas l'exemple de résultat comme une commande. Si seul `py` fonctionne, utilisez `py` à la place de `python` dans les premières commandes de ce guide.

### macOS

Téléchargez Python pour macOS sur [python.org](https://www.python.org/downloads/macos/), ouvrez le fichier .pkg et suivez l'installation. Ouvrez ensuite Terminal via la recherche Spotlight et lancez :

```bash
python3 --version
```

Une version au moins égale à 3.11 est attendue. Ne supprimez pas le Python fourni par le système. Dans ce guide, utilisez `python3` à la place de `python` sous macOS.

### Ubuntu ou Debian

Ouvrez Terminal et vérifiez d'abord `python3 --version`. Si Python ou venv manque, et si vous administrez cette machine :

```bash
sudo apt update
sudo apt install python3 python3-venv
```

Le mot de passe peut ne pas s'afficher pendant la saisie : c'est normal. Vérifiez ensuite `python3 --version`. Si la version fournie est inférieure à 3.11, demandez de l'aide pour une version prise en charge ; ces commandes ne garantissent pas une mise à niveau de votre distribution. Pour une autre distribution, suivez sa documentation officielle plutôt que de copier les commandes apt.

### Si cela bloque

« Commande introuvable » ou « n'est pas reconnu » signifie que le terminal ne trouve pas Python. Fermez et rouvrez le terminal, puis vérifiez l'installation officielle. Si le Microsoft Store s'ouvre sans afficher de version, Python n'est pas encore utilisable par cette commande. Ne passez pas à la suite avant d'avoir une version affichée.

Si vous voyez `>>>`, vous avez ouvert Python en mode interactif. Tapez `exit()` puis Entrée pour retrouver le terminal. Les commandes commençant par python se saisissent dans le terminal, pas derrière `>>>`.

## 4 Ouvrir le terminal au bon endroit

### Le point important

Le terminal travaille dans un dossier courant. Pour qu'il trouve agent.py, ce dossier doit être celui où se trouve agent.py. On copie uniquement les lignes de commande, jamais les marques ``` ni un préfixe PS C:\...> ou $.

### Windows pas à pas

1. Ouvrez le dossier contenant agent.py dans l'Explorateur de fichiers.
2. Faites un clic droit dans une zone vide puis « Ouvrir dans le terminal », si ce menu est disponible.
3. Sinon, ouvrez PowerShell puis tapez `cd ` (avec un espace), collez le chemin du dossier entre guillemets et appuyez sur Entrée. Remplacez le chemin d'exemple par le vôtre :

```powershell
cd "C:\Users\VotreNom\Documents\Formation Afrocodeurs\premier-agent-ia"
```

4. Vérifiez où vous êtes :

```powershell
Get-Location
```

5. Affichez les fichiers :

```powershell
Get-ChildItem
```

### macOS et Linux pas à pas

Ouvrez un terminal. Tapez `cd ` avec un espace, puis le chemin du dossier entre guillemets. Sur macOS, on peut glisser le dossier depuis le Finder après `cd ` pour insérer son chemin. Exemple à adapter :

```bash
cd "$HOME/Downloads/premier-agent-ia"
```

Vérifiez le dossier puis les fichiers :

```bash
pwd
ls
```

### Résultat attendu

La liste contient agent.py, diagnostic.py et le dossier data. Si vous ne les voyez pas, ne cherchez pas à modifier le code : corrigez d'abord le dossier courant.

### Votre premier diagnostic

Sous Windows, tapez :

```powershell
python diagnostic.py
```

Sous macOS ou Linux :

```bash
python3 diagnostic.py
```

Le diagnostic doit afficher des lignes OK et « Vous pouvez lancer la simulation ». Il ne demande aucune clé, n'installe rien et ne contacte aucun service. En cas d'erreur, notez la ligne concernée et utilisez [la fiche de demande d'aide](AIDE.md).

## 5 Réussir sans modèle ni dépense

### Où taper

Dans le terminal ouvert dans le dossier du kit. Laissez la page du guide ouverte dans le navigateur et revenez au terminal pour chaque commande.

### Une commande puis une vérification

Sous Windows :

```powershell
python agent.py --demo "Comment s'inscrire à l'atelier fictif ?"
```

Sous macOS ou Linux :

```bash
python3 agent.py --demo "Comment s'inscrire à l'atelier fictif ?"
```

`agent.py` est le fichier exécuté. `--demo` demande une simulation prédéfinie, sans modèle. Le texte entre guillemets est la mission. Les guillemets permettent de garder la phrase en un seul morceau.

### Ce qui doit apparaître

Une réponse commençant par SIMULATION, puis :

```text
Statut : completed_unverified
Preuves : .../premier-agent-ia/runs/un-identifiant
```

Le chemin et l'identifiant varient selon votre ordinateur. `completed_unverified` signifie « le programme a terminé une réponse qui reste à vérifier », pas « la réponse est forcément correcte ».

### Retrouver la preuve

Retournez dans le gestionnaire de fichiers, ouvrez runs puis le dossier créé le plus récemment. Ouvrez state.json avec un éditeur de texte ; ne modifiez pas son contenu. Cherchez `model_calls` et `tool_calls`. Pour cette simulation, vous devez trouver 2 et 1. L'outil a réellement recherché les documents, mais les décisions du fournisseur sont simulées.

### Tester le programme

Dans le même terminal, lancez :

```text
python -m unittest discover -s tests -v
```

Sur macOS/Linux, remplacez le premier mot par python3. La fin affiche OK. Le nombre de tests peut augmenter avec les versions du kit. Une ligne FAILED ou ERROR demande de lire le message, pas de cocher la réussite.

### Si cela bloque

Si agent.py est introuvable, reprenez l'étape du dossier courant. Si le programme attend une saisie ou semble coincé, Ctrl+C l'arrête. Si vous avez une erreur avec la clé API dans ce test, vérifiez que `--demo` est présent : ce mode n'utilise aucune clé.

### Ce que vous pouvez déjà dire

« Je sais lancer un programme, retrouver ses traces et distinguer simulation et modèle réel. » Vous n'avez pas encore à comprendre tout le code.

## 6 Ouvrir la carte et garder son travail

### Windows

Dans le dossier extrait, double-cliquez sur DEMARRER-WINDOWS.bat. Une fenêtre de terminal s'ouvre, puis votre navigateur. Si le double-clic ne fonctionne pas, utilisez le terminal déjà préparé :

```text
python serve.py
```

### macOS et Linux

Dans le terminal du dossier du kit :

```bash
python3 serve.py
```

Gardez ce terminal ouvert pendant l'utilisation de la page. Si le navigateur ne s'ouvre pas automatiquement, saisissez exactement `http://127.0.0.1:8765` dans sa barre d'adresse. Cette adresse désigne votre ordinateur ; ce n'est pas un site à publier.

### Pratiquer la sauvegarde

1. Choisissez « Je pars de zéro » dans la carte.
2. Ouvrez une étape, cochez seulement un résultat que vous avez obtenu et écrivez une note courte.
3. Actualisez la page : la case et la note doivent rester.
4. Ouvrez Ma sauvegarde puis Exporter ma progression. Gardez le fichier JSON dans votre dossier personnel.
5. Pour arrêter le serveur, revenez à son terminal et appuyez sur Ctrl+C.
6. Plus tard, relancez serve.py et revenez à la même adresse avec le même navigateur et le même profil. Utilisez Reprendre mon parcours.

Le dossier runs contient les preuves des programmes ; la page conserve vos cases et notes dans le navigateur. Ce sont deux stockages différents. Exporter la progression ne sauvegarde pas les rapports du dossier runs.

### La suite

Passez au cadrage, puis aux leçons de construction. Utilisez [le guide de pratique accompagnée](PRATIQUE-GUIDEE.md) pour les commandes du vrai modèle, l'écriture d'un rapport et l'analyse des erreurs. Le VPS est un prolongement facultatif. Votre première réussite peut rester entièrement sur votre ordinateur.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-35EA3AA6EDDE. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
