# Origine et traçabilité du kit

Référence du kit : AFROCODEURS-PREMIER-AGENT-2026. Édition AfroCodeurs — CodeScooper. Contact pour autorisation ou vérification de version : codescooper@gmail.com.

## Marques intégrées

Les supports pédagogiques portent une mention de droits et un identifiant stable par fichier. Les scripts et les pages portent des commentaires ou métadonnées d'origine. Les fiches de leçon affichent aussi leur référence. Les ressources de tiers conservent leurs licences et ne reçoivent pas une attribution qui en changerait l'auteur.

Ces marques ne sont ni des instructions cachées pour les IA, ni des outils de surveillance. Elles ne contiennent aucun identifiant de lecteur. Le kit ne transmet aucune information lors de la lecture ou de la vérification d'origine.

## Manifeste de version

ORIGINE.json contient l'identifiant du kit, la date de génération déclarée, les identifiants de fichiers et leurs empreintes SHA-256. Une empreinte change si le fichier change. Le manifeste lui-même et le ZIP de téléchargement imbriqué sont exclus de son propre inventaire pour éviter une référence circulaire.

Pour vérifier une distribution extraite, avant de modifier les exercices :

```text
python verifier_origine.py
```

Sur macOS/Linux, utiliser python3. Un résultat conforme signifie que les fichiers inventoriés correspondent au manifeste présent. Les fichiers créés par vos exercices, votre progression et les dossiers runs ne sont pas couverts. Si vous modifiez un exemple pour apprendre, il est normal que sa vérification indique une modification.

Reconstruire le kit avec build_release.py crée un nouveau manifeste correspondant aux fichiers actuels. Cela ne signifie pas que vos modifications ont été approuvées par AfroCodeurs et n'accorde aucun droit de redistribution.

## Éléments conservés à la construction

La construction produit aussi un fichier premier-agent-ia.zip.sha256 à côté du ZIP. Une copie du manifeste et l'empreinte de l'archive sont conservées dans le dossier local .adi/provenance de l'éditeur, hors de la distribution. Garder cette copie de référence séparée des fichiers diffusés permet de comparer ultérieurement un exemplaire à cette version.

Le manifeste et les marques sont des éléments de traçabilité. Ils peuvent être supprimés ou réécrits par une personne qui modifie le kit. Ils ne constituent pas une signature numérique, un horodatage certifié, une protection anticopie ou une preuve juridique autonome de création ou de propriété. Aucune de ces garanties n'est annoncée.

## Conditions d'utilisation

Les [droits et demandes d'autorisation](DROITS-ET-AUTORISATIONS.md) s'appliquent aux contenus originaux. Les polices et autres éléments de tiers conservent leurs conditions propres.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-46AFF70CBB4A. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
