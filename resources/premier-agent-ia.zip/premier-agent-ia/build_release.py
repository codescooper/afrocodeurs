# AFROCODEURS-ORIGINE | AFRO-PAI-780F52470AD3 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
"""Vérifie les liens locaux et crée un ZIP sans secrets ni traces de missions."""
import json
from pathlib import Path
import re
import zipfile
import shutil
import hashlib
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
FILES = [
    "README.md", "TUTORIEL.md", "VPS.md", "EXERCICES.md", "ANIMATION.md",
    "SOURCES-ET-LIMITES.md", "VALIDATION.md", "agent.py", "build_release.py", ".gitignore",
    "data/ateliers.md", "data/charte.md", "tests/test_agent.py", "tests/test_provenance.py",
    "evaluation/cas.json", "evaluation/grille.csv", "templates/CADRAGE.md",
    "templates/FICHE-MISSION.md", "deploy/provider.env.example",
    "serve.py", "build_web.py", "EXPLORATEUR.md",
    "explorateur/dist/index.html", "explorateur/dist/style.css", "explorateur/dist/app.js",
    "explorateur/dist/progress.js", "explorateur/dist/kit-data.js", "explorateur/test-progress.cjs",
    "DEMARRER-WINDOWS.bat", "demarrer.command", "IDENTITE-VISUELLE.md",
    "COMMENCER-ICI.html", "DEBUTER.md", "AIDE.md", "PRATIQUE-GUIDEE.md", "diagnostic.py",
    "DROITS-ET-AUTORISATIONS.md", "COMMUNAUTE.md", "TRACABILITE.md",
    "marquer_origine.py", "verifier_origine.py",
    "explorateur/dist/assets/fonts.css",
    "explorateur/dist/assets/space-grotesk-0.woff2", "explorateur/dist/assets/space-grotesk-1.woff2",
    "explorateur/dist/assets/geist-mono-0.woff2", "explorateur/dist/assets/geist-mono-1.woff2",
    "explorateur/dist/assets/space-grotesk-OFL.txt", "explorateur/dist/assets/geist-mono-OFL.txt",
]


def main():
    import marquer_origine
    import build_web
    marquer_origine.main(FILES)
    build_web.main()
    for name in FILES:
        file = ROOT / name
        if not file.is_file():
            raise ValueError(f"Fichier absent : {name}")
        if file.suffix == ".md":
            for target in re.findall(r"\]\(([^)]+)\)", file.read_text(encoding="utf-8")):
                if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", target) and not (file.parent / target.split("#")[0]).exists():
                    raise ValueError(f"Lien cassé : {name} -> {target}")
    cases = json.loads((ROOT / "evaluation/cas.json").read_text(encoding="utf-8"))
    if len(cases) != 20 or len({case["id"] for case in cases}) != 20:
        raise ValueError("Les vingt cas d'évaluation doivent avoir des identifiants uniques")
    records = [dict(path=name, id=marquer_origine.file_id(name),
                    sha256=hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),
                    rights='third-party-OFL' if '/assets/' in name else 'AfroCodeurs-original')
               for name in FILES]
    manifest = dict(format=1, kit_id=marquer_origine.KIT_ID, publisher='AfroCodeurs — CodeScooper',
                    contact='codescooper@gmail.com', generated_at=datetime.now(timezone.utc).isoformat(),
                    exclusions=['ORIGINE.json', 'explorateur/dist/kit.zip', 'runs', '.adi', '.venv'], files=records)
    manifest_path = ROOT / 'ORIGINE.json'
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    distributed = FILES + ['ORIGINE.json']
    archive = ROOT.parent / "premier-agent-ia.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
        for name in distributed:
            output.write(ROOT / name, "premier-agent-ia/" + name)
    with zipfile.ZipFile(archive) as output:
        if output.testzip() is not None:
            raise ValueError("Archive endommagée")
    shutil.copyfile(archive, ROOT / "explorateur/dist/kit.zip")
    archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    checksum = archive_hash + '  ' + archive.name + '\n'
    archive.with_suffix('.zip.sha256').write_text(checksum, encoding='utf-8')
    history = ROOT / '.adi/provenance'
    history.mkdir(parents=True, exist_ok=True)
    stem = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+archive_hash[:12]
    (history/(stem+'.json')).write_bytes(manifest_path.read_bytes())
    (history/(stem+'.sha256')).write_text(checksum, encoding='utf-8')
    print(f"Liens locaux valides, 20 cas valides, {len(distributed)} fichiers : {archive}")


if __name__ == "__main__":
    main()
