# Sources et état de vérification

Version de travail du 25 novembre 2026. Ce kit pédagogique Afrocodeurs accompagne la création d'un premier agent documentaire, de son cadrage à ses tests et à son exécution privée sur VPS.

## Sources officielles consultées

- [Python pour Windows](https://docs.python.org/3/using/windows.html) et [Téléchargements Windows](https://www.python.org/downloads/windows/) : vérifiés le 25 novembre 2026 pour tenir compte du gestionnaire d'installation actuel. Les écrans peuvent varier ; le contrôle final reste une version Python 3.11 ou supérieure affichée dans le terminal.

- [Anthropic — Building effective agents](https://www.anthropic.com/research/building-effective-agents) : distinction workflows et agents, simplicité et outils. Les exemples d'outillage de cet article ancien évoluent ; les principes servent de référence conceptuelle.
- [Ollama — OpenAI compatibility](https://docs.ollama.com/api/openai-compatibility) : compatibilité partielle et accès local à `/v1/chat/completions`. L'adaptateur utilise ce protocole, sans SDK tiers.
- [Ollama — Tool calling](https://docs.ollama.com/capabilities/tool-calling) : cycle appel d'outil puis réinjection du résultat. Le format natif montré sur cette page diffère du format compatible utilisé par ce kit.
- [API Chat Completions](https://developers.openai.com/api/reference/python/resources/chat) : format de référence des messages et appels de fonctions. Les autres fournisseurs compatibles peuvent avoir des différences.
- [Python — venv](https://docs.python.org/3/library/venv.html) : création d'environnements et invocation directe de leurs exécutables.
- [LangGraph — Persistence](https://docs.langchain.com/oss/python/langgraph/persistence) : état, checkpoints et mémoire. Référence pour une évolution ; LangGraph n'est pas installé dans ce projet.
- [OpenAI — Safety in building agents](https://developers.openai.com/api/docs/guides/agent-builder-safety) : risques d'injection et contrôles. Les recommandations conceptuelles servent ici ; le produit Agent Builder n'est pas une dépendance.
- [Docker — Installation Ubuntu](https://docs.docker.com/engine/install/ubuntu/) : interaction des ports publiés avec les pare-feu. Docker n'est pas nécessaire dans notre déploiement.

Les explications et le code du kit sont une synthèse originale ; ces pages ne constituent pas une validation des résultats de ce projet. Vérifier les documentations au moment de chaque atelier.

## Vérifications réalisées sur ce poste

- Exécution des tests déterministes Python : voir VALIDATION.md pour le résultat exact.
- Exécution du parcours de simulation sans clé et inspection des traces.
- Vérification de la structure des vingt cas d'évaluation et des liens Markdown locaux.
- Lecture de l'adaptateur et test de son protocole avec un serveur HTTP local simulé : ce test ne remplace pas une API réelle.

## Vérifications qui restent à réaliser

- Un vrai modèle Ollama : le programme Ollama n'est pas disponible sur ce poste au moment de la rédaction.
- Un appel à une API réelle compatible : aucune clé ni dépense n'a été utilisée.
- Les vingt scénarios avec un vrai modèle : la grille reste volontairement vide.
- Installation et exécution sur un VPS Ubuntu réel ; les commandes sont fournies pour cet atelier.
- Parcours sur une machine vierge par un débutant, puis préparation des captures et vidéos avant publication.

## Limites fonctionnelles explicites

Le kit fournit un agent unique CLI, pour un opérateur de confiance. Il ne fournit ni application web, ni serveur HTTP public, ni inscription réelle, ni outil email, ni orchestrateur réseau. Il n'implémente pas de base vectorielle, de mémoire personnelle durable ou de reprise automatique après crash. Les checkpoints servent à l'inspection et ne garantissent pas une transaction avec les outils.

Les limites d'appels ne constituent pas un plafond monétaire. Le délai CLI n'est pas une coupure forcée de tout traitement. Le prompt ne garantit ni fidélité aux sources ni immunité aux injections. Les données utilisateur et passages sont conservés dans les traces et peuvent être envoyés au modèle configuré.

Le statut `completed_unverified` signifie seulement qu'une réponse finale non vide a été produite. Une validation humaine et des tests avec le modèle choisi restent nécessaires.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-25395F411267. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
