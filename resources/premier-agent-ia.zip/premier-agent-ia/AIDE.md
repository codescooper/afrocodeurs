# Se débloquer sans repartir de zéro

## Les mots utiles

| Mot | Sens dans ce kit |
|---|---|
| Terminal | Fenêtre pour écrire des commandes à l'ordinateur |
| Commande | Instruction lancée avec Entrée dans le terminal |
| Dossier courant | Dossier dans lequel le terminal cherche les fichiers |
| Script | Fichier de code que l'on exécute, comme agent.py |
| Python | Programme qui exécute les fichiers .py |
| Modèle ou LLM | Système qui interprète les messages et produit une réponse ou une demande d'outil |
| Agent | Programme associant un modèle, des outils et une boucle de décisions limitée |
| Outil | Fonction autorisée que le programme peut exécuter pour le modèle |
| API | Moyen structuré de demander un service à un autre programme |
| Clé API | Secret qui autorise l'accès à un fournisseur ; ne pas le partager |
| Variable d'environnement | Réglage transmis au programme par le terminal qui le lance |
| JSON | Texte structuré avec des noms et des valeurs, utilisé pour les échanges et les traces |
| Trace ou log | Enregistrement de ce qui s'est passé pendant l'exécution |
| Simulation | Scénario prédéfini pour tester la mécanique sans modèle |
| VPS | Ordinateur loué à distance, à administrer ; inutile pour commencer |
| SSH | Connexion à un terminal distant, utilisée plus tard pour le VPS |

## Lire une erreur en quatre actions

1. Arrêtez les essais répétés et conservez le message.
2. Vérifiez le dossier courant : agent.py doit y apparaître.
3. Relevez la commande exacte, votre système et la dernière ligne d'erreur. Ne publiez ni clé ni donnée personnelle.
4. Corrigez une seule chose, relancez la même commande, comparez le résultat.

| Vous voyez | Première action |
|---|---|
| python introuvable | Vérifier l'installation ; essayer py sous Windows ou python3 sous macOS/Linux |
| can't open file ou fichier introuvable | Ouvrir le terminal dans le dossier où se trouve agent.py |
| >>> | Taper exit() pour quitter l'interpréteur avant les commandes du guide |
| --demo mais réponse étrange | La simulation utilise une question prédéfinie ; changer la mission ne mesure pas un modèle |
| La page locale ne répond pas | Vérifier que le terminal du serveur est ouvert ; relancer serve.py |
| Port 8765 occupé | Ouvrir la page à l'adresse indiquée ; si c'est un autre programme, demander de l'aide plutôt que le fermer au hasard |
| failed | Lire error_type dans state.json ; vérifier fournisseur, connexion et modèle |
| HTTPError | Vérifier identifiant du modèle, clé, format compatible, quota ; masquer la clé dans toute demande d'aide |
| step_limit | Examiner les appels ; cette limite arrête une boucle, elle ne prouve pas une réponse correcte |
| Une note a disparu | Vérifier adresse, navigateur et profil ; importer la sauvegarde JSON si nécessaire |

## Demander de l'aide utile

Copiez ce formulaire dans une note ou un message au groupe. Remplacez les champs, retirez les informations privées et ne transmettez pas le fichier de configuration contenant votre clé.

```text
Mon système : Windows / macOS / Linux
L'étape du guide :
Le résultat que j'attendais :
La commande exacte, sans secret :
La dernière ligne d'erreur, sans secret :
Est-ce que agent.py apparaît dans mon dossier courant ? oui/non
Ce que j'ai déjà vérifié :
```

Une capture peut aider, mais une commande et une erreur copiées en texte sont plus faciles à analyser. Ne modifiez pas plusieurs fichiers au hasard et n'augmentez pas les limites pour masquer une boucle.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-ECF69C2E14ED. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
