# Exécuter son premier agent sur un VPS

Ce parcours déplace la même application en ligne de commande sur un serveur Linux. Vous la pilotez par SSH. Il ne publie pas d'API et n'ouvre aucun port applicatif. On obtient un outil privé pour un opérateur, pas encore un SaaS.

Le parcours ci-dessous cible Ubuntu 24.04 LTS ou une version Ubuntu compatible disposant de Python 3.11+. Les commandes s'appliquent à un VPS de formation neuf : adapter les comptes et règles réseau sur un serveur existant. Le déploiement réel exige votre serveur et vos accès ; les fichiers fournis ne prouvent pas qu'il a été exécuté.

## 1 Choisir où tourne le modèle

| Option | Serveur applicatif | Contraintes |
|---|---|---|
| API distante | Un petit VPS peut suffire pour le script | Internet, clé, facturation et envoi des passages au fournisseur |
| Ollama sur le VPS | Mémoire et stockage adaptés au modèle | Tester le matériel ; un petit VPS sans GPU peut être lent |
| Ollama sur votre PC | Ne pas configurer localhost sur le VPS en pensant joindre le PC | `127.0.0.1` désigne toujours la machine exécutant le programme |

Pour une première expérience VPS, une API compatible réduit les besoins matériels. Le code est identique : seules les variables changent. Aucun achat de serveur n'est nécessaire pour finir le parcours local.

## 2 Créer un accès SSH

Sur votre ordinateur, créer une clé dédiée si vous n'en avez pas :

```text
ssh-keygen -t ed25519 -C "afrocodeurs-formation"
```

Garder la clé privée sur l'ordinateur. Ajouter uniquement la clé publique dans l'interface de votre hébergeur. Utiliser l'utilisateur initial fourni par celui-ci pour se connecter. Remplacer `IP_DU_VPS` et `UTILISATEUR_INITIAL` dans les commandes suivantes.

```text
ssh UTILISATEUR_INITIAL@IP_DU_VPS
```

Vérifier l'empreinte du serveur avec celle fournie par l'hébergeur avant de l'accepter. Conserver un accès à la console du fournisseur pour récupérer une configuration SSH erronée.

Dans le terminal SSH, préparer le serveur :

```bash
sudo apt update
sudo apt install python3 python3-venv ufw
sudo adduser afroagent
sudo install -d -m 700 -o afroagent -g afroagent /home/afroagent/.ssh
```

Dans votre terminal local, afficher votre clé publique :

```powershell
Get-Content "$env:USERPROFILE\.ssh\id_ed25519.pub"
```

Sous Linux ou macOS : `cat ~/.ssh/id_ed25519.pub`. Si vous avez choisi un autre nom de clé, utiliser ce chemin. Copier la ligne publique. Dans le terminal SSH, ouvrir `sudo nano /home/afroagent/.ssh/authorized_keys`, coller cette ligne et enregistrer, puis :

```bash
sudo chown afroagent:afroagent /home/afroagent/.ssh/authorized_keys
sudo chmod 600 /home/afroagent/.ssh/authorized_keys
```

Depuis **un deuxième terminal local**, vérifier `ssh afroagent@IP_DU_VPS`. Garder le premier accès ouvert jusqu'à réussite. Le compte applicatif n'a pas besoin de privilèges sudo pour exécuter l'agent.

## 3 Limiter le réseau

Sur un VPS neuf administré avec le premier compte disposant de sudo :

```bash
sudo ufw allow OpenSSH
sudo ufw enable
sudo ufw status verbose
```

Si SSH utilise un port différent de 22, autoriser ce port avant d'activer le pare-feu. Vérifier également le pare-feu de l'hébergeur. Aucun besoin d'ouvrir 8000, 11434, 80 ou 443 pour ce parcours. L'agent fait seulement des connexions sortantes vers le modèle, ou utilise Ollama en loopback.

## 4 Transférer le projet

Sur votre ordinateur, créer une archive propre en excluant clés, environnement et missions. Utiliser le ZIP de distribution fourni avec le kit, ou créer une archive du code et des supports seulement. Depuis le dossier parent du kit :

```text
scp premier-agent-ia.zip afroagent@IP_DU_VPS:/home/afroagent/
```

Sur le serveur, connecté comme `afroagent` :

```bash
cd /home/afroagent
python3 -m zipfile -e premier-agent-ia.zip .
cd premier-agent-ia
python3 -m venv .venv
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python agent.py --demo "Comment participer à l'atelier fictif ?"
```

Le ZIP fourni contient un dossier racine `premier-agent-ia`. Vérifier `pwd` et `ls` : `agent.py` doit être dans le dossier courant. Si un fichier du même nom existe déjà, extraire d'abord dans un nouveau dossier de version pour éviter les écrasements.

**Point de contrôle :** la simulation passe sur le serveur, avant toute clé API.

## 5 Configurer le modèle sans exposer la clé

Toujours comme `afroagent`, créer un fichier privé hors du projet :

```bash
umask 077
mkdir -p ~/.config/afroagent
nano ~/.config/afroagent/provider.env
```

Pour un fournisseur distant, recopier `deploy/provider.env.example` et remplacer les trois valeurs. Il s'agit de syntaxe shell : les valeurs sont entre guillemets simples et le fichier ne doit contenir que votre configuration de confiance. `source` exécute un fichier shell : ne jamais sourcer un document récupéré ou fourni par un participant.

```bash
chmod 600 ~/.config/afroagent/provider.env
set -a
source ~/.config/afroagent/provider.env
set +a
cd ~/premier-agent-ia
.venv/bin/python agent.py "Quelles sont les conditions d'inscription à l'atelier fictif ? Cite les sources."
unset AGENT_API_KEY
```

Pour Ollama installé sur le même VPS, garder `http://127.0.0.1:11434/v1` comme URL et choisir le modèle téléchargé. Suivre son installation officielle, tester sa disponibilité et conserver le service en écoute locale. Le moteur ne fournit pas l'installation d'Ollama ni le modèle lui-même.

**Point de contrôle :** une mission avec un vrai modèle produit un appel documentaire et une réponse justifiée. Documenter la consommation et le temps réels.

## 6 Exploiter et sauvegarder

L'agent s'exécute à la demande, puis quitte. Il n'a pas besoin d'un service permanent. Ne pas ajouter un redémarrage automatique : celui-ci pourrait rejouer une mission ou créer une nouvelle dépense. Une session SSH coupée peut arrêter le processus. Les missions longues et la reprise durable sont des évolutions à concevoir, pas des propriétés acquises ici.

Après chaque mission importante :

1. Lire `state.json` et son statut.
2. Vérifier les sources et le rapport éventuel.
3. Consulter le compteur d'appels et le fournisseur pour le coût.
4. Conserver une preuve expurgée, jamais une clé.

Sauvegarder les sources et, si nécessaire, les résultats de formation. Exemple sur le serveur :

```bash
cd ~/premier-agent-ia
mkdir -p ~/sauvegardes-afroagent
chmod 700 ~/sauvegardes-afroagent
tar -czf ~/sauvegardes-afroagent/formation-$(date +%Y%m%d-%H%M%S).tar.gz data runs
```

Télécharger une copie sur un stockage que vous contrôlez. Si les données deviennent sensibles, définir chiffrement, durée de conservation et accès. Tester la restauration dans un autre dossier ; voir une archive dans un répertoire ne prouve pas qu'elle est restaurable.

Pour mettre à jour, transférer une nouvelle version dans un autre dossier, refaire les tests et les cas critiques, puis l'utiliser. Garder l'ancienne version jusqu'à validation. Faire les mises à jour système avec le compte administrateur et consulter les recommandations de l'hébergeur sur les redémarrages.

## 7 Ce qu'il faudra ajouter avant une API publique

Une interface accessible à plusieurs personnes nécessite un serveur applicatif maintenu, TLS, authentification, autorisations, séparation des données et états par utilisateur, limitation des requêtes, files de travaux et budgets par compte. Les écritures humaines doivent alors passer par une vraie interface d'approbation liée à l'action, pas par un terminal partagé.

Il faut aussi isoler les fichiers de l'agent, stocker les secrets côté serveur, contrôler les sorties réseau, surveiller les erreurs, dédupliquer les actions et évaluer les réponses. Un heartbeat ou un statut `online` ne démontre aucune exécution de tâche.

Ne pas exposer directement Ollama ou un serveur de développement sur Internet pour remplacer ces éléments. Si Docker est ajouté plus tard, vérifier ses règles de publication de ports : elles peuvent contourner certaines règles UFW. Aucun conteneur ni port publié n'est nécessaire dans ce premier déploiement.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-9F14CD5AF381. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
