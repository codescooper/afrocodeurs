# Cadrage de mon premier agent

Nom du participant :

## Besoin

Utilisateur et problème observé :

Méthode actuelle et temps approximatif :

Pourquoi un agent plutôt qu'un formulaire, une recherche ou un script :

## Contrat

Mission en une phrase :

Entrées et provenance :

Résultat attendu et exemple correct :

Sources autorisées :

Outils nécessaires et permissions réelles :

Actions automatiques :

Actions soumises à validation :

Actions techniquement impossibles :

## Limites

Appels modèle maximum :

Appels outils maximum :

Temps indicatif et timeout :

Limite de dépense côté fournisseur :

Réaction en cas d'information absente ou contradictoire :

Données conservées, accès et durée :

## Vérification

Trois missions normales :

Trois cas d'échec :

Deux tentatives de manipulation :

Preuves à conserver :

Critères de passage au VPS :

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-3DB733A36006. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
