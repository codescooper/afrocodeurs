# Pratiquer avec un accompagnement pas à pas

Ces fiches complètent les leçons techniques. Elles utilisent le même projet et les mêmes fichiers. Pour Windows, les commandes utilisent PowerShell et python ; pour macOS/Linux, utilisez Bash et python3. Ne mélangez pas les syntaxes de variables des deux systèmes. Les durées de la carte sont indicatives : faites une pause dès qu'un résultat est vérifié.

## cadrer

### Votre exercice accompagné

Ouvrez templates/CADRAGE.md dans un éditeur de texte. Faites une copie appelée mon-cadrage.md pour garder le modèle vide. Vous pouvez utiliser le Bloc-notes sous Windows. Sous macOS, travaillez en texte brut, pas dans un document Word ; conservez l'extension .md.

Complétez d'abord seulement ces trois phrases :

```text
Mon utilisateur : une personne qui veut comprendre les conditions de l'atelier fictif.
Sa question : de quel matériel a-t-elle besoin ?
Une réponse correcte : un ordinateur avec Python 3.11 ou supérieur, selon ateliers.md.
```

Puis ajoutez les limites : « pas d'email, pas de paiement, pas de suppression ». Vous n'avez pas besoin de choisir tous les outils possibles. Le programme fourni possède déjà les deux fonctions nécessaires.

**Vérifiez :** quelqu'un d'autre peut retrouver votre réponse attendue dans data/ateliers.md. Si vous choisissez une question personnelle dont le corpus ne contient pas la réponse, revenez d'abord à l'exemple.

## installer

### Créer un environnement sans se perdre

Un environnement virtuel est un dossier séparé pour les outils Python du projet. Il ne remplace ni le projet ni le modèle. Dans le terminal du dossier contenant agent.py, exécutez une ligne à la fois :

```text
python -m venv .venv
```

Sous macOS/Linux, commencez par python3. La commande peut ne rien afficher quand elle réussit. Vérifiez qu'un dossier .venv est apparu ; ne déplacez pas agent.py dedans.

Sous Windows :

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Sous macOS/Linux :

```bash
.venv/bin/python -m unittest discover -s tests -v
```

Le résultat doit finir par OK. Si vous avez terminé le parcours d'initiation, cette vérification confirme le même programme avec le Python de l'environnement. Les commandes du tutoriel qui commencent simplement par python utilisent le Python disponible dans votre terminal ; celles qui commencent par .venv utilisent explicitement cet environnement.

## modele

### Choisir une seule option

La simulation a validé les mécanismes. Pour construire votre premier agent IA, il reste à obtenir une trace produite avec un vrai modèle. Si vous n'avez pas le matériel ou le budget, conservez la simulation comme étape intermédiaire et organisez un essai sur un poste partagé autorisé.

**Option locale :** Ollama télécharge un modèle sur votre ordinateur. Le téléchargement nécessite Internet, de l'espace disque et du temps. Un modèle 8B peut dépasser les capacités d'un petit ordinateur ; ne lancez pas ce téléchargement sur un forfait limité sans vérifier sa taille.

**Option API :** le modèle tourne chez un fournisseur. Votre ordinateur fait moins de calculs, mais la connexion reste nécessaire et les appels peuvent être facturés. Choisissez un modèle prenant en charge les appels d'outils et notez ses tarifs avant de créer une clé. Le kit n'effectue pas d'achat pour vous.

### Ollama une action à la fois

1. Installer Ollama depuis son site officiel, puis ouvrir un nouveau terminal.
2. Taper `ollama --version`. Une version doit apparaître. Sinon, revenir à l'installation.
3. Taper `ollama pull qwen3:8b`. Attendre la fin du téléchargement ; ne pas fermer le terminal pendant cette opération.
4. Taper `ollama list`. Le modèle doit apparaître. Ce modèle est un exemple du kit, pas une garantie d'adaptation à toute machine.
5. Dans le terminal du kit, configurer l'adresse et le modèle avec les commandes de votre système indiquées dans la leçon, puis lancer la mission.

L'URL `http://127.0.0.1:11434/v1` est celle d'Ollama. L'URL `http://127.0.0.1:8765` ouvre la page du guide. Elles désignent deux programmes différents. Ne remplacez pas l'une par l'autre.

### API et valeurs à remplacer

Relevez dans la documentation de votre fournisseur l'adresse de base compatible et l'identifiant exact du modèle. Une URL de page web où l'on discute avec un chatbot n'est pas forcément une adresse d'API. Remplacez ADRESSE-DU-FOURNISSEUR et IDENTIFIANT-DU-MODELE dans les commandes de la leçon ; ne laissez pas ces mots tels quels.

Une variable définie dans PowerShell avec `$env:` ne se configure pas de la même façon dans Bash, qui utilise `export`. Ces réglages sont liés au terminal courant. Si vous fermez le terminal puis en ouvrez un autre, refaites la configuration.

Le programme ne lit pas automatiquement un .env. Ne créez pas ce fichier en espérant qu'il remplace ces commandes. Ne placez pas une clé dans les notes de la page. Le masque de saisie protège l'affichage ; il ne rend pas la clé publique ni partageable.

### La première mission réelle

```text
python agent.py "Consulte les documents. L'inscription à l'atelier fictif est-elle gratuite ? Cite le fichier source."
```

Sous macOS/Linux, utilisez python3. Contrairement à la simulation, la commande ne contient pas --demo. Patientez : la durée dépend du modèle et de la machine. Une erreur doit être diagnostiquée avant un nouvel essai ; ne répétez pas des appels payants sans vérifier.

**Trois preuves à trouver :** dans state.json, model n'est pas simulation-sans-llm ; un appel search_docs figure dans les messages ; la réponse cite ateliers.md et parle de l'atelier fictif. Si l'une manque, notez ce qui s'est passé, sans cocher la réussite.

## outils

### Lire le code sans devoir tout comprendre

Ouvrez agent.py dans un éditeur sans le modifier. Recherchez successivement TOOLS, execute_tool et run. Vous devez seulement pouvoir dire : « le modèle propose ; le programme vérifie ; une fonction autorisée agit ; son résultat retourne au modèle ».

### Faire un rapport accompagné

1. Dans le terminal correctement configuré pour votre modèle, lancez :

```text
python agent.py "Consulte les documents, prépare un bref rapport des conditions de participation à l'atelier fictif avec les sources et propose de le sauvegarder."
```

2. Si le programme affiche un rapport et demande « Tapez OUI », lisez le texte puis tapez NON pour le premier essai.
3. Ouvrez le dossier de preuves indiqué à la fin. Il ne doit pas contenir rapport.md. Un message du modèle ne remplace pas cette vérification.
4. Relancez une nouvelle mission identique. Cette fois, tapez OUI après relecture si le rapport est correct.
5. Ouvrez le nouveau dossier de preuves. Vérifiez rapport.md et son contenu.

Si aucune question n'est affichée, l'outil n'a peut-être pas été demandé. Regardez la trace : ne tapez pas OUI au hasard dans le terminal. Reformulez une fois en demandant explicitement save_report, puis notez l'échec si le modèle ne l'appelle toujours pas.

## documents

### Vérifier une réponse ligne par ligne

Posez d'abord « Quel matériel prévoir pour l'atelier fictif ? ». Ouvrez data/ateliers.md et retrouvez la phrase sur Python 3.11. Copiez ce passage dans votre fiche de mission.

Posez ensuite « Quel est le numéro WhatsApp réel de l'organisateur ? ». Le document ne le contient pas. Une réponse honnête indique que l'information manque ; tout numéro donné est un échec à noter.

Vous pouvez maintenant faire une copie du kit pour vos essais, ajouter un court document fictif dans data et poser une question dont la réponse est un mot présent dans ce document. Gardez l'original pour comparer. La recherche ne comprend pas toujours les synonymes : un premier résultat vide n'est pas une panne du modèle.

## memoire

### Ouvrir les bons fichiers

Dans runs, ouvrez le dossier de la mission qui vous intéresse, puis state.json avec un éditeur. Cherchez status, model_calls et tool_calls. Dans events.jsonl, chaque ligne représente un événement. Ne supprimez pas une ligne pour faire disparaître une erreur.

Si plusieurs dossiers existent, utilisez le chemin affiché dans le terminal. Une nouvelle mission crée un nouveau dossier. Le bouton « Reprendre mon parcours » reprend la lecture du guide, pas l'exécution de l'agent. Une mission interrompue n'est pas automatiquement relancée.

## robustesse

### Provoquer un arrêt sans API ni dépense

Dans le terminal du kit :

```text
python agent.py --demo --max-steps 1 "Comment s'inscrire ?"
```

Le résultat attendu est step_limit : la simulation a demandé une recherche, mais un second appel était nécessaire pour la réponse finale. Il ne s'agit pas d'un bug à masquer.

Relancez sans --max-steps 1. Le statut attendu redevient completed_unverified. Notez la différence. Passez ensuite aux cas du vrai modèle pour mesurer sa qualité, sans confondre les deux types de test.

## securite

### Manipulation guidée dans une copie du kit

Faites une copie du dossier avant l'exercice. Dans son dossier data, créez attaque-test.md avec un éditeur de texte, en conservant l'extension .md. Utilisez seulement le faux texte de la leçon ; ne placez aucun secret dans le fichier.

Avec un vrai modèle, lancez la question sur l'inscription. Retrouvez le passage hostile dans les messages de state.json. S'il n'a pas été récupéré, l'attaque n'a pas été testée : vous ne pouvez pas conclure qu'elle a été bloquée.

Si le passage est présent, vérifiez la réponse et les outils exécutés. Le programme n'a pas d'outil pour envoyer un email ni lancer une commande. Mais une fausse information dans sa réponse reste un échec. Retirez seulement le fichier d'attaque que vous venez de créer et refaites la mission normale.

## demo

### Préparer une petite démonstration

Préparez trois choses avant de présenter : votre cadrage, une mission réelle sourcée et une erreur comprise. Présentez d'abord votre utilisateur et sa question, puis lancez une seule mission courte. Montrez le fichier source et la trace. Dites ce qui reste manuel et ce qui ne fonctionne pas encore.

Vous pouvez réussir cette étape en local. Le VPS n'est pas une condition de réussite du premier agent.

## evaluation

### Remplir la première ligne ensemble

Ouvrez evaluation/cas.json pour lire C01. Lancez sa mission avec un vrai modèle et copiez le chemin du dossier de preuves dans votre fiche. Ouvrez ensuite evaluation/grille.csv avec un tableur ou un éditeur. Conservez ses en-têtes ; remplissez la ligne C01 avec la date, le modèle exact, l'identifiant runs et votre conclusion.

Pour C01, une réussite exige la gratuité de l'inscription fictive, la source ateliers.md et une recherche effectivement observée. Un texte qui semble correct mais n'a pas consulté les documents ne suffit pas. Les autres lignes se remplissent de la même façon.

Si vous ne maîtrisez pas encore le CSV, utilisez [la fiche de mission](templates/FICHE-MISSION.md) pour chaque cas et demandez une relecture avant de reporter les résultats. La priorité est la preuve, pas la mise en forme.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-70BEC7485A69. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
