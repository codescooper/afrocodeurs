# Rejoindre AfroCodeurs et faire grandir le kit

Vous avez terminé une étape, rencontré un blocage ou construit votre premier agent ? Venez partager votre expérience avec la communauté AfroCodeurs. Vous pouvez aussi contacter CodeScooper pour aller plus loin, envisager un accompagnement ou proposer une collaboration.

## Les liens de la communauté

- [Rejoindre la communauté WhatsApp](https://chat.whatsapp.com/BfD3XW8X48ACQN5V8XkBye)
- [Rejoindre le serveur Discord](https://discord.gg/F7mNU63pMQ)
- [Visiter le site AfroCodeurs](https://www.afrocodeurs.org/)
- [Contacter CodeScooper par email](mailto:codescooper@gmail.com)

Ces invitations WhatsApp et Discord ont été relevées dans le site AfroCodeurs le 25 novembre 2026. L'API publique Discord a confirmé ce jour que l'invitation correspond au serveur AfroCodeurs ; l'accès au groupe WhatsApp n'a pas été testé. Leur disponibilité peut évoluer. Si un lien ne fonctionne plus, retrouver les liens depuis le site ou écrire à codescooper@gmail.com. Aucun compte n'a été créé et aucune inscription n'a été effectuée pour vous.

## Pour aller plus loin

Décrivez ce que vous souhaitez construire, votre niveau, les étapes déjà réalisées et votre contrainte principale. Vous pouvez demander un échange sur votre projet ou sur la suite de votre apprentissage. Aucune disponibilité, formule d'accompagnement ou gratuité n'est garantie par cette invitation.

## Transmettre un retour utile

Votre retour peut améliorer le parcours pour les prochains apprenants. Indiquez :

1. L'étape ou le fichier concerné et la référence du kit.
2. Votre système et votre parcours choisi, sans information privée.
3. Ce que vous avez compris ou ce qui vous a arrêté.
4. Le résultat attendu et le résultat observé.
5. Une suggestion concrète de correction ou d'explication.

Les questions, erreurs relevées, propositions de sujet et expériences de terrain sont les bienvenues. Utilisez si nécessaire [la fiche de demande d'aide](AIDE.md). Ne transmettez aucune clé API, aucun mot de passe ni donnée confidentielle dans vos messages ou captures.

Partager votre retour ou votre expérience n'autorise pas à republier les supports du kit. Pour toute reproduction, même partielle, demander une autorisation écrite à codescooper@gmail.com selon [la notice de droits](DROITS-ET-AUTORISATIONS.md).

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-08D40F179609. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
