@echo off
rem AFROCODEURS-ORIGINE | AFRO-PAI-0B3554B1C2C3 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 serve.py
) else (
  python serve.py
)
if errorlevel 1 pause
