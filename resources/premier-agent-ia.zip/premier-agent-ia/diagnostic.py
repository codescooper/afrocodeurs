# AFROCODEURS-ORIGINE | AFRO-PAI-D11E4754ADEF | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
"""Vérifie les prérequis locaux sans réseau ni installation."""
from pathlib import Path
import sys
import tempfile


def main():
    root = Path(__file__).resolve().parent
    ok = sys.version_info >= (3, 11)
    print(('OK' if ok else 'ERREUR') + ' Python : ' + sys.version.split()[0] + ' (3.11 minimum)')
    print('Dossier du kit :', root)
    print('Dossier du terminal :', Path.cwd())
    for name in ['agent.py', 'data/ateliers.md', 'tests/test_agent.py', 'serve.py']:
        exists = (root / name).is_file()
        ok = ok and exists
        print(('OK ' if exists else 'ERREUR fichier absent : ') + name)
    try:
        with tempfile.TemporaryFile(dir=root):
            pass
        print('OK : écriture possible dans le dossier du kit')
    except OSError:
        ok = False
        print('ERREUR : extrayez le kit dans un dossier personnel où vous pouvez écrire')
    print('Vous pouvez lancer la simulation.' if ok else 'Corrigez les lignes ERREUR avant de continuer.')
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
