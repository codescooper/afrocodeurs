# AFROCODEURS-ORIGINE | AFRO-PAI-2F5A8E500555 | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md
"""Applique des marques documentaires idempotentes, sans réseau ni suivi."""
import hashlib
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
KIT_ID = 'AFROCODEURS-PREMIER-AGENT-2026'


def file_id(name):
    return 'AFRO-PAI-' + hashlib.sha256(name.encode('utf-8')).hexdigest()[:12].upper()


def main(files=None):
    if files is None:
        from build_release import FILES
        files = FILES
    for name in files:
        path = ROOT / name
        if not path.is_file() or '/assets/' in name or name.endswith(('kit-data.js', '.json', '.csv')):
            continue
        if path.suffix not in {'.md', '.py', '.js', '.cjs', '.css', '.html', '.bat', '.command', '.example'}:
            continue
        text = path.read_text(encoding='utf-8')
        ref = file_id(name)
        stamp = f'AFROCODEURS-ORIGINE | {ref} | © 2026 AfroCodeurs — CodeScooper | Autorisation : codescooper@gmail.com | Voir DROITS-ET-AUTORISATIONS.md'
        if path.suffix == '.md':
            text = re.sub(r'(?m)^© 2026 AfroCodeurs — CodeScooper\. Référence AFRO-PAI-[A-F0-9]+\.[^\n]*\n?', '', text)
            text = text.rstrip() + f'\n\n© 2026 AfroCodeurs — CodeScooper. Référence {ref}. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.\n'
        elif path.suffix == '.html':
            text = re.sub(r'<!-- AFROCODEURS-ORIGINE .*?-->\s*', '', text)
            text = text.replace('<head>', '<!-- ' + stamp + ' -->\n<head>', 1)
        elif path.suffix == '.css':
            text = re.sub(r'\n?/\* AFROCODEURS-ORIGINE .*?\*/\n?', '', text)
            # Garder @charset en première position lorsqu'il existe.
            pos = text.index(';') + 1 if text.startswith('@charset') else 0
            text = text[:pos] + '\n/* ' + stamp + ' */\n' + text[pos:].lstrip('\n')
        else:
            prefix = 'rem ' if path.suffix == '.bat' else '// ' if path.suffix in {'.js', '.cjs'} else '# '
            text = re.sub(r'(?m)^(?:# |// |rem )AFROCODEURS-ORIGINE .*\n?', '', text)
            lines = text.splitlines(keepends=True)
            at = 1 if lines and (lines[0].startswith('#!') or lines[0].lower().startswith('@echo')) else 0
            lines.insert(at, prefix + stamp + '\n')
            text = ''.join(lines)
        path.write_text(text, encoding='utf-8')


if __name__ == '__main__':
    main()
