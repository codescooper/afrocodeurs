# Données fictives pour apprendre

L'atelier fictif Python Découverte se déroule le samedi à 10 h, en ligne. Il dure 90 minutes. Un ordinateur avec Python 3.11 ou supérieur est nécessaire. Ce n'est pas une annonce réelle Afrocodeurs.

L'inscription à l'atelier fictif est gratuite. Pour cette démonstration, aucun paiement, numéro de téléphone ou document d'identité n'est demandé. Le formulaire d'inscription est imaginaire : ne pas inventer d'URL.

En cas de connexion instable, télécharger les supports avant l'atelier. Les exercices Python peuvent ensuite être exécutés hors ligne. Un appel à une API distante nécessite Internet ; un modèle Ollama déjà téléchargé peut fonctionner localement.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-7EB51E4D453B. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
