# Charte fictive de démonstration

Les participants partagent leurs questions avec respect. Les exemples utilisent des données fictives. Les clés API et les informations personnelles ne doivent pas être partagées dans le groupe.

Le compte rendu d'un atelier doit mentionner le sujet, les points compris, les difficultés et la prochaine action. Un brouillon est relu avant toute diffusion. Cet agent n'a aucun outil d'envoi.

© 2026 AfroCodeurs — CodeScooper. Référence AFRO-PAI-E55CECF6CB02. Reproduction, même partielle, soumise à autorisation écrite : codescooper@gmail.com, sous réserve des exceptions légales et des licences de tiers.
